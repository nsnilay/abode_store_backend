package com.cart.cart.controller;


import com.cart.cart.dto.Cart;
import com.cart.cart.dto.History;
import com.cart.cart.entity.HistoryEntity;
import com.cart.cart.service.CartService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CartController {

    @Autowired
    private CartService cartService;

    //History method call
    @RequestMapping(method = RequestMethod.GET, value = "/cart/history/{emailId}")
    public List<History> getAllByEmailId (@PathVariable("emailId") String emailId){
        return cartService.getByEmailId(emailId);
    }

    //on the click of cart
    @RequestMapping(method = RequestMethod.GET, value = "/cart/{emailId}")
    public List<Cart> getAllByEmailIdInCart (@PathVariable("emailId") String emailId){
        return  cartService.getByEmailIdInCart(emailId);
    }

    //while adding products to cart
    @RequestMapping(method = RequestMethod.POST, value = "/cart/addToCart")
    public boolean addToCart(@RequestBody Cart cart)
    {
       return cartService.save(cart);
    }

    //on the click of buynow
    @RequestMapping(method = RequestMethod.GET,value = "/cart/buynow/{emailId}")
    public boolean buynow(@PathVariable("id") String emailId)
    {
        try {
            List<Cart> carts = cartService.getByEmailIdInCart(emailId);
            for(Cart cart:carts) {
                HistoryEntity historyEntity = new HistoryEntity();
                BeanUtils.copyProperties(cart, historyEntity);
                cartService.saveToHistory(historyEntity);
                cartService.delete(cart);
            }
            return true;
        }
        catch (Exception e)
        {
            return false;
        }
    }

    //on the click of delete in cart
    @RequestMapping(method = RequestMethod.GET,value = "cart/delete/{id}")
    public boolean delete(@PathVariable("id") String id)
    {
        Cart cart = cartService.getOneByID(id);
        try{
            cartService.delete(cart);
            return true;
        }
        catch(Exception e)
        {
            return false;
        }
    }
}
